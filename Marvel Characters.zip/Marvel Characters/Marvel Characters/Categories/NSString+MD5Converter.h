//
//  NSString+MD5Converter.h
//  Marvel Characters
//
//  Created by Максим on 29.08.16.
//  Copyright © 2016 Максим. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5Converter)

-(NSString *)md5;

@end
