//
//  StoriesItem.m
//  Marvel Characters
//
//  Created by Максим on 29.08.16.
//  Copyright © 2016 Максим. All rights reserved.
//

#import "StoriesItem.h"
#import "Stories.h"

@implementation StoriesItem

// Insert code here to add functionality to your managed object subclass

@end
