//
//  EventsItem.m
//  Marvel Characters
//
//  Created by Максим on 29.08.16.
//  Copyright © 2016 Максим. All rights reserved.
//

#import "EventsItem.h"
#import "Events.h"

@implementation EventsItem

// Insert code here to add functionality to your managed object subclass

@end
