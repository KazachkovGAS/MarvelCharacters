//
//  Thumbnail+CoreDataProperties.m
//  Marvel Characters
//
//  Created by Максим on 29.08.16.
//  Copyright © 2016 Максим. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Thumbnail+CoreDataProperties.h"

@implementation Thumbnail (CoreDataProperties)

@dynamic extension;
@dynamic path;
@dynamic imageContext;

@end
